
import os, uuid, json
from dotenv import load_dotenv
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
ENV_FILE = os.path.join(BASE_DIR, '.env')
# Resolve beside app.py, not the PowerShell working directory. A blank inherited
# environment variable must not hide a valid key in this project's .env file.
if os.path.isfile(ENV_FILE):
    load_dotenv(dotenv_path=ENV_FILE, override=True)
from flask import Flask, request, jsonify, send_from_directory
from werkzeug.utils import secure_filename
from utils.resume_parser import build_candidate_profile, extract_text_from_pdf
from utils.career_agent import CareerAgent
from utils.multi_agent import MultiAgentCoordinator, ProfileAgent
from utils.llm import completion_json
from db import init_db, upsert_application, get_application, list_applications, update_status, transition_application, save_candidate, get_candidate

UPLOAD_DIR=os.path.join(BASE_DIR,"uploads"); os.makedirs(UPLOAD_DIR,exist_ok=True)
JOBS_CSV=os.path.join(BASE_DIR,"data","jobs.csv")

app=Flask(__name__,static_folder="static",static_url_path="")
app.config["MAX_CONTENT_LENGTH"]=5*1024*1024
agent=CareerAgent(JOBS_CSV)
coordinator=MultiAgentCoordinator(agent)
profile_agent=ProfileAgent()
CANDIDATES={}

init_db()

@app.get("/")
def index(): return send_from_directory(app.static_folder,"index.html")

@app.get("/api/config")
def config_status():
    return jsonify(llm_ready=bool(os.getenv("GROQ_API_KEY", "").strip()),
                   env_file_found=os.path.isfile(ENV_FILE))

@app.get("/api/config/test")
def test_llm_connection():
    try:
        response = completion_json('Reply only as JSON: {"ok": true}')
        if response.get('ok') is not True:
            raise RuntimeError('Groq returned an unexpected response')
        return jsonify(llm_connected=True)
    except RuntimeError as exc:
        return jsonify(llm_connected=False, error=str(exc)),503

@app.post("/api/upload_resume")
def upload_resume():
    if "resume" not in request.files: return jsonify(error="No resume uploaded"),400
    f=request.files["resume"]
    if not f.filename or not f.filename.lower().endswith(".pdf"): return jsonify(error="Only PDF resumes are supported"),400
    cid=str(uuid.uuid4()); path=os.path.join(UPLOAD_DIR,cid+".pdf"); f.save(path)
    try: profile=profile_agent.run(path)
    except Exception as e: return jsonify(error=f"Could not parse PDF: {e}"),422
    CANDIDATES[cid]=profile
    save_candidate(cid,profile)
    return jsonify(candidate_id=cid,profile=profile)

@app.before_request
def restore_candidate():
    cid=request.args.get("candidate_id") or (request.get_json(silent=True) or {}).get("candidate_id")
    if cid and cid not in CANDIDATES:
        profile=get_candidate(cid)
        if profile: CANDIDATES[cid]=profile

@app.get("/api/profile")
def candidate_profile():
    cid,err=candidate_or_404()
    if err:return err
    return jsonify(candidate_id=cid,profile=CANDIDATES[cid])

def candidate_or_404():
    cid=request.args.get("candidate_id") or (request.get_json(silent=True) or {}).get("candidate_id")
    if cid not in CANDIDATES: return None, (jsonify(error="Unknown candidate. Upload a resume first."),404)
    return cid,None

@app.get("/api/recommend")
def recommend():
    cid,err=candidate_or_404()
    if err:return err
    top_n=max(1,min(int(request.args.get("top_n",5)),20))
    keyword=request.args.get("keyword"); location=request.args.get("location")
    source=request.args.get("source", "local")
    df=agent.search_jobs(keyword,location,source)
    return jsonify(candidate_id=cid,source=source,live_error=agent.live_error,
                   recommendations=agent.matcher.rank_jobs(CANDIDATES[cid],df,top_n))

@app.get("/api/advise")
def advise():
    cid,err=candidate_or_404()
    if err:return err
    try:
        result=coordinator.advise(CANDIDATES[cid],request.args.get('keyword'),
            request.args.get('location'),request.args.get('source','local'),
            max(1,min(int(request.args.get('top_n',5)),20)))
        return jsonify(candidate_id=cid,**result)
    except ValueError as exc: return jsonify(error=str(exc)),400
    except RuntimeError as exc: return jsonify(error=str(exc)),503

@app.get("/api/job_analysis")
def job_analysis():
    cid,err=candidate_or_404()
    if err:return err
    try: return jsonify(coordinator.learning.run(CANDIDATES[cid],request.args.get('job_id')))
    except KeyError: return jsonify(error='Job not found'),404
    except ValueError as exc: return jsonify(error=str(exc)),400
    except RuntimeError as exc: return jsonify(error=str(exc)),503

@app.get("/api/recommend_agentic")
def recommend_agentic():
    """Phase 5: LLM-driven version of /api/recommend. Requires GROQ_API_KEY."""
    cid,err=candidate_or_404()
    if err:return err
    goal=request.args.get("goal")
    try:
        result=agent.recommend_jobs_agentic(CANDIDATES[cid], goal=goal)
    except RuntimeError as e:
        return jsonify(error=str(e)),503
    return jsonify(candidate_id=cid,**result)

@app.get("/api/jobs")
def jobs():
    keyword=request.args.get("keyword"); location=request.args.get("location")
    source=request.args.get("source", "local")
    df=agent.search_jobs(keyword,location,source)
    rows=df.head(50).fillna("").to_dict("records")
    return jsonify(jobs=rows,total=len(df),source=source,live_error=agent.live_error)

@app.get("/api/job/<job_id>")
def job_details(job_id):
    d=agent.get_job_details(job_id)
    return jsonify(d) if d else (jsonify(error="Job not found"),404)

@app.get("/api/skill_gap")
def skill_gap():
    cid,err=candidate_or_404()
    if err:return err
    jid=request.args.get("job_id"); job=agent.get_job_details(jid)
    if not job:return jsonify(error="Job not found"),404
    return jsonify(job_id=jid,job_title=job["job_title"],**agent.analyze_skill_gap_for_job(CANDIDATES[cid],jid))

@app.get("/api/learning_plan")
def learning_plan():
    cid,err=candidate_or_404()
    if err:return err
    jid=request.args.get("job_id"); job=agent.get_job_details(jid)
    if not job:return jsonify(error="Job not found"),404
    return jsonify(job_id=jid,learning_plan=agent.create_learning_plan_for_job(CANDIDATES[cid],jid))

@app.post("/api/application/prepare")
def prepare_application():
    data=request.get_json(silent=True) or {}
    cid=data.get("candidate_id"); jid=data.get("job_id")
    if cid not in CANDIDATES:return jsonify(error="Unknown candidate"),404
    if not CANDIDATES[cid].get('resume_text'):
        saved_pdf=os.path.join(UPLOAD_DIR,cid+'.pdf')
        if os.path.isfile(saved_pdf):
            try:
                CANDIDATES[cid]['resume_text']=extract_text_from_pdf(saved_pdf)[:12000]
                save_candidate(cid,CANDIDATES[cid])
            except Exception:
                pass  # The reviewer will report that source evidence is unavailable.
    job=agent.get_job_details(jid)
    if not job:return jsonify(error="Job not found"),404
    try: material,trace=coordinator.prepare(CANDIDATES[cid],job)
    except RuntimeError as exc: return jsonify(error=str(exc)),503
    try: row=upsert_application(cid,jid,"draft",material["tailored_resume"],material["cover_letter"],json.dumps(material["application_answers"]))
    except ValueError as exc: return jsonify(error=str(exc)),400
    return jsonify(application=row,job=job,agent_trace=trace,**material)

@app.get("/api/applications")
def applications():
    cid=request.args.get("candidate_id")
    if cid not in CANDIDATES:return jsonify(error="Unknown candidate"),404
    rows=list_applications(cid)
    for r in rows:
        try:r["application_answers"]=json.loads(r["application_answers"] or "[]")
        except: r["application_answers"]=[]
    return jsonify(applications=rows)

@app.get("/api/application/<job_id>")
def application(job_id):
    cid=request.args.get("candidate_id")
    if cid not in CANDIDATES:return jsonify(error="Unknown candidate"),404
    row=get_application(cid,job_id)
    if not row:return jsonify(error="Application not prepared"),404
    try:row["application_answers"]=json.loads(row["application_answers"] or "[]")
    except:row["application_answers"]=[]
    return jsonify(application=row)

@app.post("/api/application/approve")
def approve():
    data=request.get_json(silent=True) or {}; cid=data.get("candidate_id"); jid=data.get("job_id")
    if cid not in CANDIDATES:return jsonify(error="Unknown candidate"),404
    row=get_application(cid,jid)
    if not row:return jsonify(error="Prepare the application before approval"),400
    if row["status"] not in ("draft","rejected"): return jsonify(error=f"Cannot approve from status {row['status']}"),400
    try:return jsonify(application=transition_application(cid,jid,"approve"))
    except ValueError as exc:return jsonify(error=str(exc)),400

@app.post("/api/application/apply")
def apply():
    data=request.get_json(silent=True) or {}; cid=data.get("candidate_id"); jid=data.get("job_id")
    if cid not in CANDIDATES:return jsonify(error="Unknown candidate"),404
    row=get_application(cid,jid)
    if not row:return jsonify(error="Prepare the application first"),400
    if row["status"]!="approved":return jsonify(error="Human approval is required before marking an application submitted"),400
    # MVP intentionally does not submit to a third-party site. It records the candidate's action.
    try:return jsonify(application=transition_application(cid,jid,"apply"),message="Application marked submitted. External website submission is not automated in this version.")
    except ValueError as exc:return jsonify(error=str(exc)),400

@app.post("/api/application/status")
def status():
    data=request.get_json(silent=True) or {}; cid=data.get("candidate_id"); jid=data.get("job_id"); st=data.get("status")
    allowed={"saved","draft","approved","submitted","interview","rejected","withdrawn"}
    if cid not in CANDIDATES:return jsonify(error="Unknown candidate"),404
    if st not in allowed:return jsonify(error=f"Status must be one of {sorted(allowed)}"),400
    if not get_application(cid,jid):return jsonify(error="Application not found"),404
    try:return jsonify(application=update_status(cid,jid,st))
    except ValueError as exc:return jsonify(error=str(exc)),400

@app.errorhandler(413)
def too_large(e): return jsonify(error="Resume must be 5 MB or smaller"),413

if __name__=="__main__":
    app.run(debug=True,port=int(os.environ.get("PORT",5000)))
