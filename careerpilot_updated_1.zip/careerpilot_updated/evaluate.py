"""Reproducible offline comparison; does not fabricate human-rated quality scores."""
import json, time
from pathlib import Path
from utils.career_agent import CareerAgent
from utils.multi_agent import MultiAgentCoordinator

ROOT = Path(__file__).resolve().parent
PROFILES = [
    {'name':'Data learner','skills':['Python','SQL'],'education':'B.Tech','experience_years':0},
    {'name':'Backend learner','skills':['Python','Flask'],'education':'B.E.','experience_years':0},
    {'name':'ML learner','skills':['Python','Scikit-learn'],'education':'B.Sc','experience_years':0},
]

def main():
    career = CareerAgent(str(ROOT / 'data' / 'jobs.csv'))
    career.jobs_df = career.jobs_df.head(30).copy()  # fixed, fast comparison subset
    coordinator = MultiAgentCoordinator(career)
    results = {}
    for mode in ('none','basic','agentic'):
        rows = []
        for profile in PROFILES:
            started = time.perf_counter()
            result = coordinator.advise(profile, source='local', top_n=1, rag_mode=mode)
            analysis = result['top_job_analysis']
            rows.append({'profile':profile['name'], 'job_id':result['recommendations'][0]['job_id'],
                         'missing_skills':analysis['skill_gap']['missing_skills'],
                         'retrieval_decision':analysis['rag']['retrieval_decision'],
                         'source_count':len(analysis['rag']['sources']),
                         'latency_seconds':round(time.perf_counter()-started,3)})
        results[mode] = rows
    print(json.dumps({'method':'Offline structural comparison, no LLM or human ratings',
                      'results':results,
                      'not_measured':['job relevance','grounding accuracy','plan quality',
                                      'review effectiveness','LLM consistency']},indent=2))

if __name__=='__main__': main()
