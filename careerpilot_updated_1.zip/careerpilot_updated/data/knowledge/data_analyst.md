# Data Analyst Roadmap
## Foundations
Start with spreadsheet analysis, SQL filtering, joins, aggregation and descriptive statistics. Practice cleaning a small public dataset and explain assumptions.
## Visualization and Power BI
Learn chart choice and visual storytelling, then Power BI data import, Power Query transformation, relationships, DAX measures and dashboard design. Build a dashboard and check each metric against the source data.
## Portfolio and interviews
Publish one documented end-to-end project. Be ready to explain joins, missing data, metrics, and why a visual answers a business question.
