# Machine Learning Roadmap
## Foundations
Study Python, statistics, data cleaning, train-validation-test splits, baseline models and error analysis. Avoid data leakage and report suitable metrics.
## Practical project
Train a small model with scikit-learn, compare a baseline, document limitations and serve predictions through an API. Learn deployment and monitoring after evaluation.
