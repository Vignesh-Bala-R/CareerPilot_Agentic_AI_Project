# Python Developer Roadmap
## Core development
Practice Python data structures, functions, testing, error handling, packaging and Git. Build a small API with Flask or another framework and add automated tests.
## Services and deployment
Learn REST conventions, database queries, authentication concepts, Docker basics and deployment. Document API endpoints and test failure paths.
