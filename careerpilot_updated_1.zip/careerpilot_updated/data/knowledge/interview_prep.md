# Interview Preparation
## Evidence and honesty
Connect each claimed skill to a real project or exercise. Use specific examples of the problem, your contribution, the tools used and the outcome. Never claim an unlisted qualification or professional experience.
## Practice
Prepare concise explanations of one project, a technical challenge and a learning goal. Verify application claims against the original resume before approval.
