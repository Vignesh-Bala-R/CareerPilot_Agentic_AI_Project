"""
Phase 1 - Resume Processing.
Extracts text from a resume PDF, identifies known skills, and builds a
structured candidate profile.
"""
import re
from pypdf import PdfReader

# Master skill vocabulary. In production this could be pulled from the
# jobs dataset itself (union of all job "skills" columns) to stay in sync.
KNOWN_SKILLS = [
    "Python", "Java", "SQL", "Machine Learning", "React", "Spring Boot",
    "TensorFlow", "PyTorch", "Scikit-learn", "Pandas", "NumPy", "Docker",
    "Kubernetes", "AWS", "Azure", "Terraform", "CI/CD", "Linux",
    "JavaScript", "TypeScript", "HTML", "CSS", "Tailwind CSS", "Flask",
    "REST API", "Microservices", "Hibernate", "ETL", "Airflow", "Spark",
    "Statistics", "Data Visualization", "Selenium", "Test Automation",
    "LLM", "LangChain", "Agile", "Product Strategy", "Roadmapping",
    "Communication", "C++", "C#", "Go", "Node.js", "MongoDB", "PostgreSQL",
    "Git", "NLP", "Deep Learning", "Excel", "PowerBI", "Tableau",
    "Oracle Fusion", "Oracle EBS", "PL/SQL", "AOL", "General Ledger",
    "Cash Management", "Fixed Assets", "Accounts Payable", "Accounts Receivable",
]

# Pre-build a lowercase lookup so matching is case-insensitive
_SKILL_LOOKUP = {s.lower(): s for s in KNOWN_SKILLS}


def extract_text_from_pdf(pdf_path: str) -> str:
    reader = PdfReader(pdf_path)
    text_parts = []
    for page in reader.pages:
        text_parts.append(page.extract_text() or "")
    return "\n".join(text_parts)


def extract_skills(text: str) -> list:
    """Find known skills mentioned in the resume text (word-boundary match)."""
    found = []
    text_lower = text.lower()
    for skill_lower, skill_display in _SKILL_LOOKUP.items():
        # word-boundary-ish match; handles skills with spaces/dots (C++, Node.js)
        pattern = re.escape(skill_lower)
        if re.search(rf"(?<![a-zA-Z0-9]){pattern}(?![a-zA-Z0-9])", text_lower):
            found.append(skill_display)
    return sorted(set(found))


def extract_experience_years(text: str) -> float:
    """Best-effort extraction of total years of experience from resume text."""
    patterns = [
        r"(\d+(?:\.\d+)?)\+?\s*years?\s+(?:of\s+)?experience",
        r"experience\s*[:\-]?\s*(\d+(?:\.\d+)?)\+?\s*years?",
    ]
    for p in patterns:
        m = re.search(p, text, re.IGNORECASE)
        if m:
            return float(m.group(1))
    return 0.0


def extract_education(text: str) -> str:
    """Best-effort extraction of the highest-degree line."""
    degree_keywords = [
        "b.tech", "btech", "b.e", "bachelor", "m.tech", "mtech", "master",
        "phd", "b.sc", "m.sc", "mba", "diploma",
    ]
    for line in text.splitlines():
        line_stripped = line.strip()
        if any(kw in line_stripped.lower() for kw in degree_keywords) and len(line_stripped) < 120:
            return line_stripped
    return "Not specified"


def extract_name(text: str) -> str:
    for line in text.splitlines():
        line=line.strip()
        if line and len(line.split()) <= 5 and "@" not in line and not any(ch.isdigit() for ch in line):
            if not any(k in line.lower() for k in ["resume","curriculum vitae","objective","skills","education","experience","projects"]):
                return line
    return "Candidate"

def extract_email(text: str) -> str:
    m = re.search(r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}", text)
    return m.group(0) if m else ""

def build_candidate_profile(pdf_path: str) -> dict:
    """Phase 1 end-to-end: PDF -> structured candidate profile."""
    text = extract_text_from_pdf(pdf_path)
    skills = extract_skills(text)
    experience_years = extract_experience_years(text)
    education = extract_education(text)

    return {
        "name": extract_name(text),
        "email": extract_email(text),
        "skills": skills,
        "experience_years": experience_years,
        "education": education,
        "raw_text_length": len(text),
        # Keep a bounded source excerpt for evidence-based application review.
        "resume_text": text[:12000],
    }


if __name__ == "__main__":
    import sys
    import json
    if len(sys.argv) < 2:
        print("Usage: python3 resume_parser.py <resume.pdf>")
        sys.exit(1)
    profile = build_candidate_profile(sys.argv[1])
    print(json.dumps(profile, indent=2))
