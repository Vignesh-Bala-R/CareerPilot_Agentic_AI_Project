"""
Phase 5 - Agentic layer.

Replaces the fixed search -> score -> rank chain with an LLM-driven loop:
the model sees the candidate profile and a goal, decides which tool to call,
sees the result, and decides the next step -- until it produces a final answer.

Uses Groq's free, OpenAI-compatible API by default.
"""
import os
import json
try:
    from openai import OpenAI
except ImportError:
    OpenAI = None
from utils.tool_schemas import TOOLS

GROQ_MODEL = os.environ.get("GROQ_MODEL", "openai/gpt-oss-120b")
GROQ_BASE_URL = "https://api.groq.com/openai/v1"

# Hard cap on any single tool result sent back to the model, as a safety net.
# The free Groq tier allows only 8,000 tokens/minute, and the full conversation
# history is resent on every turn, so tool results must stay small.
MAX_TOOL_RESULT_CHARS = 3000

SYSTEM_PROMPT = (
    "You are a career assistant agent helping a job candidate. You have tools to "
    "search jobs, score how well the candidate matches a job, analyze skill gaps, "
    "and build learning plans. Use the tools to investigate before answering -- do "
    "not guess job details or scores yourself. search_jobs checks both job titles "
    "and required skills, so either a role name (e.g. 'Data Scientist', 'ML Engineer', "
    "'Backend Developer') or one of the candidate's own skills (e.g. 'Python') works "
    "as a keyword -- prefer a role name close to the candidate's background first. "
    "If a search returns nothing, try at most one alternate keyword, then work with "
    "whatever results you have -- do not keep retrying indefinitely. Once you have "
    "search results, only call calculate_match_score / analyze_skill_gap_for_job on "
    "a small number of the most promising jobs (2-4). When you have enough "
    "information, stop calling tools and give a final answer: a short ranked list of "
    "your top job recommendations (job_id, title, company, match reasoning) and, for "
    "the top pick, the key skill gaps and a brief learning suggestion."
)


def _get_client() -> OpenAI:
    api_key = os.environ.get("GROQ_API_KEY")
    if not api_key:
        raise RuntimeError(
            "GROQ_API_KEY is not set. Get a free key at https://console.groq.com/keys "
            "and set it in your .env file or environment before using the agentic endpoints."
        )
    return OpenAI(api_key=api_key, base_url=GROQ_BASE_URL)


def _build_tool_map(career_agent, candidate: dict) -> dict:
    """Binds the tool schemas above to the real CareerAgent methods + this candidate."""

    def _search_jobs(keyword=None, location=None):
        # Search local jobs directly so we can match on BOTH job_title and skills --
        # the dataset only has ~12 distinct job titles (e.g. "Data Scientist",
        # "ML Engineer"), so a skill-name keyword like "Python" would otherwise
        # never match anything if we only checked job_title.
        df = career_agent.jobs_df.fillna("")
        if keyword:
            mask = (
                df["job_title"].str.contains(keyword, case=False, na=False)
                | df["skills"].str.contains(keyword, case=False, na=False)
            )
            df = df[mask]
        if location:
            df = df[df["location"].str.contains(location, case=False, na=False)]
        slim_cols = [c for c in ["job_id", "job_title", "company", "location", "skills", "experience"] if c in df.columns]
        return df[slim_cols].head(15).to_dict("records")

    return {
        "search_jobs": _search_jobs,
        "calculate_match_score": lambda job_id: career_agent.calculate_match_score(candidate, job_id),
        "analyze_skill_gap_for_job": lambda job_id: career_agent.analyze_skill_gap_for_job(candidate, job_id),
        "create_learning_plan_for_job": lambda job_id: career_agent.create_learning_plan_for_job(candidate, job_id),
    }


def _safe_tool_result_json(result) -> str:
    """Serializes a tool result and hard-truncates it if it's still too large,
    so a single unexpectedly large result can never blow the token budget."""
    payload = json.dumps(result, default=str)
    if len(payload) > MAX_TOOL_RESULT_CHARS:
        payload = payload[:MAX_TOOL_RESULT_CHARS] + '... [truncated: result too large]"}'
    return payload


def run_agent(career_agent, candidate: dict, goal: str = None, max_turns: int = 8) -> dict:
    """
    Runs the ReAct-style loop and returns:
      {
        "answer": <final natural-language answer from the model>,
        "trace": [ {tool, args, result}, ... ]   # full reasoning trace for demos/reports
      }
    """
    client = _get_client()
    tool_map = _build_tool_map(career_agent, candidate)
    goal = goal or "Find and evaluate the best-fit jobs for this candidate."

    candidate_summary = {
        "skills": candidate.get("skills", []),
        "experience_years": candidate.get("experience_years", 0),
        "education": candidate.get("education", ""),
    }

    messages = [
        {"role": "system", "content": SYSTEM_PROMPT},
        {
            "role": "user",
            "content": f"Candidate profile: {json.dumps(candidate_summary)}\n\nGoal: {goal}",
        },
    ]

    trace = []

    for _ in range(max_turns):
        response = client.chat.completions.create(
            model=GROQ_MODEL,
            messages=messages,
            tools=TOOLS,
        )
        msg = response.choices[0].message
        messages.append(msg.model_dump(exclude_none=True))

        if not msg.tool_calls:
            return {"answer": msg.content, "trace": trace}

        for call in msg.tool_calls:
            name = call.function.name
            try:
                args = json.loads(call.function.arguments or "{}")
            except json.JSONDecodeError:
                args = {}

            try:
                if name not in tool_map:
                    raise KeyError(f"Unknown tool requested by model: {name}")
                result = tool_map[name](**args)
            except Exception as exc:
                # Fed back to the model as a tool result so it can self-correct
                # (e.g. retry with a valid job_id) instead of the whole request failing.
                result = {"error": str(exc)}

            trace.append({"tool": name, "args": args, "result": result})
            messages.append(
                {
                    "role": "tool",
                    "tool_call_id": call.id,
                    "content": _safe_tool_result_json(result),
                }
            )

    return {
        "answer": "Reached max turns without a final answer. Partial reasoning is in the trace.",
        "trace": trace,
    }
