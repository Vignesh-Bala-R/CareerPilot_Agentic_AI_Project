"""Fetch and normalize live jobs from multiple free providers: Remotive and Adzuna.

Both providers are optional and independent: if one fails (network issue, missing
key, rate limit) the other still contributes results, and callers can fall back
to the bundled CSV entirely if both are unavailable or return no matches.
"""
import os
import json
import re
from html import unescape
from urllib.parse import urlencode
from urllib.request import Request, urlopen

from utils.resume_parser import KNOWN_SKILLS


REMOTIVE_URL = "https://remotive.com/api/remote-jobs"
ADZUNA_URL = "https://api.adzuna.com/v1/api/jobs"
ADZUNA_COUNTRY = os.environ.get("ADZUNA_COUNTRY", "in")  # "in" = India; see Adzuna docs for other country codes


DOMAIN_SKILLS = [
    "JD Edwards", "JDE", "EnterpriseOne", "BI Publisher", "Orchestration",
    "BSFN", "UBE", "ERP", "QuickBooks", "Bookkeeping",
    "DAX", "Stored Procedure", "Window Functions", "CTE",
    "Oracle Fusion", "Oracle EBS", "PL/SQL", "AOL", "General Ledger",
    "Cash Management", "Fixed Assets", "Accounts Payable", "Accounts Receivable",
]


def _plain_text(value) -> str:
    return re.sub(r"\s+", " ", unescape(re.sub(r"<[^>]*>", " ", str(value or "")))).strip()


def _required_section(description) -> str:
    """Exclude clearly labeled preferred skills from required-skill coverage."""
    text = _plain_text(description)
    return re.split(r"\b(?:preferred qualifications|nice to have|bonus skills)\b", text,
                    maxsplit=1, flags=re.I)[0]


def _listing_warnings(title, description) -> list:
    """Catch obvious title/description conflicts in third-party listings."""
    intro = _plain_text(description)[:500]
    match = re.search(
        r"\b(?:looking for|hiring)\s+(?:a|an)\s+(?:highly motivated\s+)?"
        r"(software engineer|backend developer|frontend developer|data scientist|data engineer)\b",
        intro, re.I,
    )
    if match and match.group(1).lower() not in str(title or '').lower():
        return [f"The title says '{title}', but the description introduces a '{match.group(1)}' role. Confirm the listing before applying."]
    return []


def _skills_from_text(*parts) -> list:
    text = unescape(" ".join(str(p or "") for p in parts))
    # Match whole terms: "Go" must not match "goals", and "Git" must not
    # match the middle of another word. Preserve specialized job requirements.
    found = []
    for skill in KNOWN_SKILLS + DOMAIN_SKILLS:
        ending = r"s?" if skill in {"Stored Procedure", "CTE"} else ""
        # PL/SQL alone must not count as evidence of standalone SQL.
        before = r"(?<![A-Za-z0-9/])" if skill == "SQL" else r"(?<![A-Za-z0-9])"
        if re.search(before + re.escape(skill) + ending + r"(?![A-Za-z0-9])", text, re.I):
            found.append(skill)
    return list(dict.fromkeys(found))


def _experience_from_text(*parts) -> str:
    text = _plain_text(" ".join(str(p or "") for p in parts))
    patterns = [
        r"\bexperience\s*[-:]\s*(\d{1,2})\s*to\s*\d{1,2}\b",
        # Job snippets sometimes split "years" as "year s" and put a range
        # after a broken "Experience Required" heading.
        r"\b(\d{1,2})\s*[-–]\s*\d{1,2}\s*year\s*s?\b",
        r"\b(?:experience|minimum|requires?)\s*[:\-]?\s*(\d{1,2})\+?\s*years?",
        r"(\d{1,2})\+?\s*years?\s+(?:of\s+)?experience",
    ]
    for pattern in patterns:
        match = re.search(pattern, text, re.I)
        if match:
            years = min(int(match.group(1)), 30)
            return f"{years}+" if years >= 3 else "0-2"
    if re.search(r"\b(?:professional experience|only candidates who already have experience)\b", text, re.I):
        return "professional experience required"
    return "unspecified"


# ---------------- Remotive ----------------

def _normalize_remotive_job(job: dict, index: int) -> dict:
    description = job.get("description") or ""
    skills = _skills_from_text(job.get("title"), _required_section(description))
    notes = []
    if re.search(r"only candidates who already have experience|professional experience", _plain_text(description), re.I):
        notes.append("This posting requires prior professional experience; read its requirements before applying.")
    if re.search(r"US East business hours|Eastern time zone", _plain_text(description), re.I):
        notes.append("The posting requires overlap with US Eastern working hours.")
    return {
        "job_id": f"LIVE-RMT-{job.get('id', index)}",
        "job_title": job.get("title") or "Remote opportunity",
        "company": job.get("company_name") or "Unknown company",
        "location": job.get("candidate_required_location") or "Remote",
        "skills": ", ".join(skills) or "General technical skills",
        "experience": _experience_from_text(job.get("title"), description),
        "eligibility_notes": notes,
        "job_description": description,
        "application_url": job.get("url") or "",
        "source": "live-remotive",
        "published_at": job.get("publication_date") or "",
    }


def fetch_remotive_jobs(keyword: str = None, location: str = None, limit: int = 50) -> list:
    params = {"limit": min(max(limit, 1), 100)}
    if keyword:
        params["search"] = keyword
    request = Request(
        f"{REMOTIVE_URL}?{urlencode(params)}",
        headers={"User-Agent": "CareerPilot/1.0"},
    )
    with urlopen(request, timeout=8) as response:
        payload = json.load(response)

    jobs = payload.get("jobs", [])
    normalized = [_normalize_remotive_job(job, index) for index, job in enumerate(jobs, 1)]
    if location:
        location_lower = location.lower()
        normalized = [j for j in normalized if location_lower in j["location"].lower()]
    return normalized


# ---------------- Adzuna ----------------

def _normalize_adzuna_job(job: dict, index: int) -> dict:
    company = (job.get("company") or {}).get("display_name") or "Unknown company"
    location = (job.get("location") or {}).get("display_name") or "Not specified"
    title = job.get("title") or "Job opportunity"
    description = job.get("description") or ""
    skills = _skills_from_text(title, _required_section(description))
    warnings = _listing_warnings(title, description)
    return {
        "job_id": f"LIVE-ADZ-{job.get('id', index)}",
        "job_title": title,
        "company": company,
        "location": location,
        "skills": ", ".join(skills) or "General technical skills",
        "experience": _experience_from_text(title, description),
        "eligibility_notes": warnings,
        "job_description": description,
        "application_url": job.get("redirect_url") or "",
        "source": "live-adzuna",
        "published_at": job.get("created") or "",
    }


def fetch_adzuna_jobs(keyword: str = None, location: str = None, limit: int = 50) -> list:
    app_id = os.environ.get("ADZUNA_APP_ID")
    app_key = os.environ.get("ADZUNA_APP_KEY")
    if not app_id or not app_key:
        # Not configured -- treat as "no results" rather than an error, since
        # Adzuna is an optional supplementary source. Logged so this isn't silent.
        print("[live_jobs] ADZUNA_APP_ID / ADZUNA_APP_KEY not set -- skipping Adzuna, using Remotive only.")
        return []

    params = {
        "app_id": app_id,
        "app_key": app_key,
        "results_per_page": min(max(limit, 1), 50),
        "content-type": "application/json",
    }
    if keyword:
        params["what"] = keyword
    if location:
        params["where"] = location

    url = f"{ADZUNA_URL}/{ADZUNA_COUNTRY}/search/1?{urlencode(params)}"
    request = Request(url, headers={"User-Agent": "CareerPilot/1.0"})
    with urlopen(request, timeout=8) as response:
        payload = json.load(response)

    jobs = payload.get("results", [])
    return [_normalize_adzuna_job(job, index) for index, job in enumerate(jobs, 1)]


# ---------------- Combined ----------------

def fetch_live_jobs(keyword: str = None, location: str = None, limit: int = 100) -> list:
    """Fetches from both providers and merges results. Each provider fails
    independently -- if one errors out, the other's results are still returned.
    Raises only if BOTH providers fail, so callers' existing fallback-to-CSV
    logic still triggers when live data is entirely unavailable.
    """
    per_provider_limit = min(max(limit, 1), 50)
    results = []
    errors = []

    try:
        remotive_results = fetch_remotive_jobs(keyword, location, limit=per_provider_limit)
        results.extend(remotive_results)
        print(f"[live_jobs] Remotive: {len(remotive_results)} jobs")
    except Exception as exc:
        errors.append(f"Remotive: {exc}")
        print(f"[live_jobs] Remotive FAILED: {exc}")

    try:
        adzuna_results = fetch_adzuna_jobs(keyword, location, limit=per_provider_limit)
        results.extend(adzuna_results)
        print(f"[live_jobs] Adzuna: {len(adzuna_results)} jobs")
    except Exception as exc:
        errors.append(f"Adzuna: {exc}")
        print(f"[live_jobs] Adzuna FAILED: {exc}")

    if not results and errors:
        raise RuntimeError("; ".join(errors))

    return results
