"""Specialist agents with explicit coordinator handoffs."""
import json
import re
from utils.resume_parser import build_candidate_profile
from utils.rag import KnowledgeBase
from utils.llm import completion_json
from utils.application_agent import ApplicationAgent
from utils.skill_gap import analyze_skill_gap


class ProfileAgent:
    name = 'profile_agent'
    def run(self, pdf_path):
        profile = build_candidate_profile(pdf_path)
        if not profile['raw_text_length']:
            raise ValueError('No extractable text in PDF; use a text-based resume')
        return profile


class JobAgent:
    name = 'job_agent'
    def __init__(self, career): self.career = career
    def run(self, profile, keyword=None, location=None, source='local', top_n=5):
        jobs = self.career.search_jobs(keyword, location, source)
        return self.career.matcher.rank_jobs(profile, jobs, top_n)


class LearningAgent:
    name = 'learning_agent'
    def __init__(self, career):
        self.career, self.knowledge = career, KnowledgeBase()

    def run(self, profile, job_id):
        job = self.career.get_job_details(job_id)
        if not job: raise KeyError('Job not found')
        gap = self.career.analyze_skill_gap_for_job(profile, job_id)
        exp_text = str(job.get('experience') or 'unspecified')
        years = re.match(r'^(\d{1,2})\+', exp_text)
        required_years = int(years.group(1)) if years else None
        gap['experience_requirement'] = exp_text
        gap['experience_gap_years'] = max(0, required_years - float(profile.get('experience_years') or 0)) if required_years is not None else None
        default_query = f"{job['job_title']} roadmap " + ' '.join(gap['missing_skills'][:5])
        choice = completion_json(f'''Decide whether career-guide retrieval will help plan for this job.
Candidate skills: {json.dumps(profile.get('skills', []))}
Job title: {job['job_title']}
Required skills: {job.get('skills', '')}
Missing skills: {json.dumps(gap['missing_skills'])}
Return ONLY JSON: {{"retrieve": true or false, "query": "specific short search query", "reason": "short reason"}}.
Retrieve when a skill gap needs an explained study sequence. Skip when no extra guidance is needed.''')
        retrieve = choice.get('retrieve') is True
        query = str(choice.get('query') or default_query)[:200]
        decision_reason = str(choice.get('reason') or 'LLM retrieval decision')[:300]
        sources = self.knowledge.retrieve(query) if retrieve else []
        context = [{'source': s['source'], 'text': s['text']} for s in sources]
        output = completion_json(f'''You are the Learning Agent. Explain skill gaps and write a practical study flow.
The skill-gap comparison below was computed from the candidate and job skill lists. Do not claim unlisted skills as proven experience.
Candidate: {json.dumps({k: profile.get(k) for k in ('skills','education','experience_years')})}
Job: {json.dumps({k: job.get(k) for k in ('job_title','company','skills','experience','location','eligibility_notes')})}
Computed gaps: {json.dumps(gap)}
Skill coverage measures extracted skill terms ONLY. A role requiring professional experience is not an entry-level fit merely because some skills match. Explicitly explain experience and domain gaps, including unquantified professional experience requirements.
RAG mode: agentic
Retrieved guide excerpts (empty means no retrieval): {json.dumps(context)}
Use retrieved excerpts only when supplied; do not invent citations. When guidance is absent, make a reasonable general study plan and say it is not document-grounded.
Return ONLY JSON with fields:
{{"gap_explanation":"2-4 clear sentences about matches and missing skills",
"study_flow":[{{"step":1,"skill":"one missing skill","duration":"realistic estimate","study_plan":"what to learn and in what order","project":"one practice task","success_check":"observable outcome","knowledge_source":"filename from retrieved excerpts or empty string"}}]}}.
Give one ordered step for each missing skill, and an empty study_flow when none are missing.''')
        plan = output.get('study_flow')
        if not isinstance(plan, list) or not isinstance(output.get('gap_explanation'), str):
            raise RuntimeError('LLM returned an incomplete skill-gap explanation or study flow')
        allowed = {s['source'] for s in sources}
        for n, item in enumerate(plan, 1):
            if not isinstance(item, dict): raise RuntimeError('LLM returned an invalid study step')
            item['step'] = n
            item['knowledge_source'] = item.get('knowledge_source') if item.get('knowledge_source') in allowed else ''
            item['generated_by'] = 'llm'
        return {'skill_gap': gap, 'gap_explanation': output['gap_explanation'],
                'learning_plan': plan,
                'rag': {'mode': 'agentic', 'retrieval_decision': retrieve, 'reason': decision_reason,
                        'query': query if retrieve else None, 'sources': sources}}


class ReviewAgent:
    name = 'review_agent'
    def run(self, profile, job, draft):
        from openai import OpenAI
        import os
        key = os.getenv('GROQ_API_KEY', '').strip()
        if not key: raise RuntimeError('GROQ_API_KEY is missing for application review')
        client = OpenAI(api_key=key, base_url='https://api.groq.com/openai/v1',
                        timeout=35.0, max_retries=1)
        return ApplicationAgent()._review_and_revise(profile, job, draft, client)


class MultiAgentCoordinator:
    name = 'coordinator'
    def __init__(self, career):
        self.jobs = JobAgent(career)
        self.learning = LearningAgent(career)
        self.application = ApplicationAgent()
        self.review = ReviewAgent()
        self.career = career

    def advise(self, profile, keyword=None, location=None, source='local', top_n=5):
        recommendations = self.jobs.run(profile, keyword, location, source, top_n)
        trace = [{'agent': 'job_agent', 'action': 'rank_jobs', 'count': len(recommendations)}]
        # Analysis of the selected job happens in /api/job_analysis, avoiding an
        # unnecessary LLM call for a top job the student may not choose.
        return {'recommendations': recommendations, 'top_job_analysis': None,
                'agent_trace': trace, 'live_error': self.career.live_error}

    def prepare(self, profile, job):
        draft = self.application.prepare(profile, job, review=False)
        reviewed = self.review.run(profile, job, draft)
        return reviewed, [
            {'agent': 'application_agent', 'action': 'draft', 'generated_by': draft['generated_by']},
            {'agent': 'review_agent', 'action': 'review', 'verified': reviewed['verified']}]
