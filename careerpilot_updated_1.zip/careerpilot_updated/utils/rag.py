"""Small, inspectable document RAG index. No remote vector service required."""
from pathlib import Path
import re
from collections import Counter
import math

KNOWLEDGE_DIR = Path(__file__).resolve().parents[1] / 'data' / 'knowledge'


def tokens(text):
    return re.findall(r'[a-z0-9+#.]+', text.lower())


class KnowledgeBase:
    def __init__(self, directory=KNOWLEDGE_DIR):
        self.chunks = []
        for path in sorted(Path(directory).glob('*.md')):
            content = path.read_text(encoding='utf-8')
            # Heading sections are short enough to cite independently.
            for n, section in enumerate(re.split(r'(?=^## )', content, flags=re.M)):
                if section.strip():
                    self.chunks.append({'source': path.name, 'section': n,
                                        'text': section.strip()[:2000]})
        self.docs = [Counter(tokens(x['text'])) for x in self.chunks]
        self.df = Counter(word for doc in self.docs for word in doc)

    def retrieve(self, query, limit=3):
        q = set(tokens(query))
        scores = []
        for idx, doc in enumerate(self.docs):
            score = sum((1 + math.log(1 + doc[t])) *
                        math.log(1 + (len(self.docs) + 1) / (1 + self.df[t]))
                        for t in q if t in doc and len(t) > 2)
            if score > 0:
                scores.append((score, idx))
        scores.sort(key=lambda p: (-p[0], self.chunks[p[1]]['source'], p[1]))
        return [{**self.chunks[i], 'score': round(score, 2)} for score, i in scores[:limit]]


