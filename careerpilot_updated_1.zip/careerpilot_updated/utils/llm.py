"""One configured Groq client for the specialist agents."""
import json
import os
from openai import OpenAI

BASE_URL = 'https://api.groq.com/openai/v1'


def completion_json(prompt):
    key = os.getenv('GROQ_API_KEY', '').strip()
    if not key:
        raise RuntimeError('GROQ_API_KEY is missing. Copy .env.example to .env and add your Groq API key.')
    model = os.getenv('GROQ_MODEL', 'openai/gpt-oss-120b')
    try:
        client = OpenAI(api_key=key, base_url=BASE_URL, timeout=35.0, max_retries=1)
        response = client.chat.completions.create(
            model=model,
            messages=[{'role': 'user', 'content': prompt}],
            response_format={'type': 'json_object'},
        )
        return json.loads(response.choices[0].message.content)
    except Exception as exc:
        raise RuntimeError(f'LLM request failed: {exc}') from exc
