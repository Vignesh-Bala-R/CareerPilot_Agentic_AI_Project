"""
Tool schemas exposed to the LLM agent (Groq/OpenAI-compatible function-calling format).
These describe the existing CareerAgent / ApplicationAgent methods so the model
can decide which ones to call and with what arguments. No business logic lives
here -- this is purely the description layer.
"""

TOOLS = [
    {
        "type": "function",
        "function": {
            "name": "search_jobs",
            "description": (
                "Search the job listings by keyword and/or location. Returns up to 15 "
                "matching jobs with job_id, job_title, company, location, skills and "
                "experience band (no full descriptions, to keep responses small). Call "
                "this first, with a specific keyword/location narrowing the results, "
                "before scoring or analyzing any job."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "keyword": {"type": "string", "description": "Job title keyword, e.g. 'Data Analyst'"},
                    "location": {"type": "string", "description": "City or region, e.g. 'Chennai'"},
                },
                "required": [],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "calculate_match_score",
            "description": (
                "Score how well the candidate fits a specific job, using the trained "
                "match model. Returns a 0-100 match_score plus supporting features. "
                "Requires a job_id obtained from search_jobs."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "job_id": {"type": "string", "description": "The job_id to score, from search_jobs results"},
                },
                "required": ["job_id"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "analyze_skill_gap_for_job",
            "description": (
                "Compare the candidate's skills against a specific job's required skills. "
                "Returns matching_skills and missing_skills. Requires a job_id from search_jobs."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "job_id": {"type": "string", "description": "The job_id to analyze, from search_jobs results"},
                },
                "required": ["job_id"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "create_learning_plan_for_job",
            "description": (
                "Generate a short learning plan to close the candidate's skill gaps for a "
                "specific job. Requires a job_id from search_jobs. Useful once you already "
                "know which job(s) you're recommending."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "job_id": {"type": "string", "description": "The job_id to build a learning plan for"},
                },
                "required": ["job_id"],
            },
        },
    },
]
