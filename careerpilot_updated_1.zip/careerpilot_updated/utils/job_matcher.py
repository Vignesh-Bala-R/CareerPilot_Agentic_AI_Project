"""
Phase 3 - ML Job Matching.

For each candidate-job pair, builds features (matching skills, missing
skills, skill ratio, experience match, education match) and trains a
Random Forest to output a 0-100 match score.

Since we don't have historical "did this candidate get hired" labels,
the MVP trains the model on a synthetic-but-realistic label built from
a weighted rule (skill_ratio heavy, experience/education lighter) plus
noise. This keeps the *architecture* genuinely ML (Random Forest
regressor consuming engineered features) while being honest that the
labels are bootstrapped until real application-outcome data exists.
"""
import re
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestRegressor

EXPERIENCE_BAND_MIDPOINT = {
    "0-1": 0.5, "0-2": 1.0, "1-3": 2.0, "2-4": 3.0, "3-5": 4.0, "5-8": 6.5,
}


def _parse_job_skills(skills_str: str) -> set:
    return {s.strip().lower() for s in skills_str.split(",") if s.strip()}


def _experience_band_midpoint(band: str) -> float:
    if band in EXPERIENCE_BAND_MIDPOINT:
        return EXPERIENCE_BAND_MIDPOINT[band]
    match = re.fullmatch(r"(\d{1,2})\+", str(band))
    if match:
        return float(match.group(1))
    return 1.0  # Unknown experience is treated as unknown, not as a claim of seniority.


def _education_match_score(candidate_education: str) -> float:
    """Rough heuristic: does candidate have at least a bachelor's-level degree."""
    if not candidate_education:
        return 0.0
    text = candidate_education.lower()
    if any(k in text for k in ["m.tech", "mtech", "master", "phd", "mba", "m.sc"]):
        return 1.0
    if any(k in text for k in ["b.tech", "btech", "b.e", "bachelor", "b.sc"]):
        return 0.8
    if "diploma" in text:
        return 0.5
    return 0.3


def build_features(candidate: dict, job_row: pd.Series) -> dict:
    candidate_skills = {s.lower() for s in candidate.get("skills", [])}
    job_skills = _parse_job_skills(job_row["skills"])

    matching_skills = candidate_skills & job_skills
    missing_skills = job_skills - candidate_skills

    skill_ratio = len(matching_skills) / len(job_skills) if job_skills else 0.0

    candidate_exp = candidate.get("experience_years", 0.0)
    job_exp_mid = _experience_band_midpoint(job_row["experience"])
    # experience_match: 1.0 if candidate meets/exceeds required midpoint, tapering off below it
    experience_match = min(1.0, candidate_exp / job_exp_mid) if job_exp_mid > 0 else 1.0

    education_match = _education_match_score(candidate.get("education", ""))

    return {
        "matching_skills_count": len(matching_skills),
        "missing_skills_count": len(missing_skills),
        "job_skills_count": len(job_skills),
        "skill_ratio": skill_ratio,
        "experience_match": experience_match,
        "education_match": education_match,
        "_matching_skills": sorted(matching_skills),
        "_missing_skills": sorted(missing_skills),
    }


def _synthetic_label(features: dict) -> float:
    """Bootstrapped training label (0-100) used until real outcome data exists."""
    score = (
        70 * features["skill_ratio"]
        + 20 * features["experience_match"]
        + 10 * features["education_match"]
    )
    return float(np.clip(score, 0, 100))


class JobMatcher:
    def __init__(self):
        self.model = RandomForestRegressor(n_estimators=200, max_depth=6, random_state=42)
        self._trained = False

    def _feature_vector(self, feat: dict):
        return [
            feat["matching_skills_count"],
            feat["missing_skills_count"],
            feat["job_skills_count"],
            feat["skill_ratio"],
            feat["experience_match"],
            feat["education_match"],
        ]

    def train_on_synthetic_candidates(self, jobs_df: pd.DataFrame, n_synthetic_candidates: int = 150):
        """Bootstraps training data: simulate varied candidates against the
        real job postings so the Random Forest learns realistic feature -> score
        relationships. Replace with real historical application outcomes later."""
        rng = np.random.default_rng(42)
        all_job_skills = sorted({s for row in jobs_df["skills"] for s in _parse_job_skills(row)})

        X, y = [], []
        for _ in range(n_synthetic_candidates):
            n_skills = rng.integers(2, min(10, len(all_job_skills)))
            cand_skills = set(rng.choice(all_job_skills, size=n_skills, replace=False))
            cand_exp = float(rng.uniform(0, 8))
            cand_edu = rng.choice(["B.Tech", "M.Tech", "Diploma", ""])
            candidate = {"skills": list(cand_skills), "experience_years": cand_exp, "education": cand_edu}

            sample_jobs = jobs_df.sample(min(20, len(jobs_df)), random_state=rng.integers(0, 1_000_000))
            for _, job_row in sample_jobs.iterrows():
                feat = build_features(candidate, job_row)
                X.append(self._feature_vector(feat))
                y.append(_synthetic_label(feat))

        self.model.fit(X, y)
        self._trained = True

    def score(self, candidate: dict, job_row: pd.Series) -> tuple:
        feat = build_features(candidate, job_row)
        if not self._trained:
            raise RuntimeError("JobMatcher must be trained before scoring. Call train_on_synthetic_candidates().")
        pred = self.model.predict([self._feature_vector(feat)])[0]
        match_score = float(np.clip(round(pred, 1), 0, 100))
        return match_score, feat

    def rank_jobs(self, candidate: dict, jobs_df: pd.DataFrame, top_n: int = 5) -> list:
        results = []
        for _, job_row in jobs_df.iterrows():
            score, feat = self.score(candidate, job_row)
            results.append({
                "job_id": job_row["job_id"],
                "job_title": job_row["job_title"],
                "company": job_row["company"],
                "location": job_row["location"],
                "experience": job_row.get("experience", "unspecified"),
                "match_score": score,
                "matching_skills": feat["_matching_skills"],
                "missing_skills": feat["_missing_skills"],
                "application_url": job_row["application_url"],
                "source": job_row.get("source", "local"),
                "published_at": job_row.get("published_at", ""),
                "eligibility_notes": job_row.get("eligibility_notes") if isinstance(job_row.get("eligibility_notes"), list) else [],
            })
        results.sort(key=lambda r: r["match_score"], reverse=True)
        return results[:top_n]


if __name__ == "__main__":
    jobs_df = pd.read_csv("data/jobs.csv")
    matcher = JobMatcher()
    matcher.train_on_synthetic_candidates(jobs_df)

    candidate = {
        "skills": ["Python", "Java", "SQL", "Machine Learning", "React", "Spring Boot"],
        "experience_years": 1.0,
        "education": "B.Tech AI & ML",
    }
    top_jobs = matcher.rank_jobs(candidate, jobs_df, top_n=5)
    for j in top_jobs:
        print(f"{j['job_title']} @ {j['company']} -> {j['match_score']}%")
