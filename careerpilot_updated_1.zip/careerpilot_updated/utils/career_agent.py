"""
Phase 4 - Career Agent.
The central orchestrator. Exposes discrete "tools" (as named in the plan)
that a future LLM-driven Agentic layer (LangGraph, etc.) can call directly.
For the MVP, run() chains them in the fixed workflow from the plan; the
tool functions are still separated so an LLM planner can be dropped in later
without changing the underlying logic.
"""
import pandas as pd
from utils.job_matcher import JobMatcher
from utils.live_jobs import fetch_live_jobs
from utils.skill_gap import analyze_skill_gap, create_learning_plan


class CareerAgent:
    def __init__(self, jobs_csv_path: str):
        self.jobs_df = pd.read_csv(jobs_csv_path)
        self.jobs_df["source"] = "local"
        self.live_jobs_df = pd.DataFrame()
        self.live_error = ""
        self.matcher = JobMatcher()
        self.matcher.train_on_synthetic_candidates(self.jobs_df)

    # ---- Tools ----
    def search_jobs(self, keyword: str = None, location: str = None, source: str = "local") -> pd.DataFrame:
        if source == "live":
            try:
                self.live_jobs_df = pd.DataFrame(fetch_live_jobs(keyword, location))
                self.live_error = ""
            except Exception as exc:
                self.live_jobs_df = pd.DataFrame()
                self.live_error = f"Live jobs unavailable: {exc}"
            df = self.live_jobs_df
            if df.empty:
                df = self.jobs_df
        elif source == "all":
            try:
                self.live_jobs_df = pd.DataFrame(fetch_live_jobs(keyword, location))
                self.live_error = ""
            except Exception as exc:
                self.live_jobs_df = pd.DataFrame()
                self.live_error = f"Live jobs unavailable: {exc}"
            df = pd.concat([self.jobs_df, self.live_jobs_df], ignore_index=True)
        else:
            df = self.jobs_df
        if keyword:
            df = df[df["job_title"].str.contains(keyword, case=False, na=False)]
        if location:
            df = df[df["location"].str.contains(location, case=False, na=False)]
        return df

    def get_job_details(self, job_id: str) -> dict:
        all_jobs = pd.concat([self.jobs_df, self.live_jobs_df], ignore_index=True)
        row = all_jobs[all_jobs["job_id"] == job_id]
        if row.empty:
            return None
        return row.iloc[0].to_dict()

    def _get_job_row(self, job_id: str) -> pd.Series:
        all_jobs = pd.concat([self.jobs_df, self.live_jobs_df], ignore_index=True)
        row = all_jobs[all_jobs["job_id"] == job_id]
        if row.empty:
            raise KeyError(f"Job not found: {job_id}")
        return row.iloc[0]

    def calculate_match_score(self, candidate: dict, job_id: str) -> dict:
        job_row = self._get_job_row(job_id)
        score, feat = self.matcher.score(candidate, job_row)
        return {"job_id": job_id, "match_score": score, **feat}

    def analyze_skill_gap_for_job(self, candidate: dict, job_id: str) -> dict:
        job_row = self._get_job_row(job_id)
        job_skills = [s.strip() for s in job_row["skills"].split(",")]
        return analyze_skill_gap(candidate.get("skills", []), job_skills)

    def create_learning_plan_for_job(self, candidate: dict, job_id: str) -> list:
        gap = self.analyze_skill_gap_for_job(candidate, job_id)
        return create_learning_plan(gap["missing_skills"], candidate=candidate)

    # ---- Orchestrated workflow (Phase 4 example workflow) ----
    def recommend_jobs(self, candidate: dict, top_n: int = 5) -> list:
        """search jobs -> get details -> call ML model -> rank -> recommend"""
        return self.matcher.rank_jobs(candidate, self.jobs_df, top_n=top_n)

    # ---- Phase 5 - Agentic workflow ----
    def recommend_jobs_agentic(self, candidate: dict, goal: str = None) -> dict:
        """
        LLM-driven version of recommend_jobs(). Instead of always running the
        fixed search -> score -> rank chain, an LLM (via Groq) decides which
        tools to call, in what order, based on the candidate and goal. Returns
        both the final answer and the full tool-call trace for inspection.
        """
        from utils.agent_core import run_agent  # local import: only needed when this path is used
        return run_agent(self, candidate, goal=goal)