import os, sys, tempfile, unittest, types
from pathlib import Path
from unittest.mock import patch
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
try: import openai
except ImportError: sys.modules['openai'] = types.SimpleNamespace(OpenAI=object)
from utils.rag import KnowledgeBase
from utils.resume_parser import build_candidate_profile
from utils.career_agent import CareerAgent
from utils.multi_agent import MultiAgentCoordinator

ROOT = Path(__file__).resolve().parents[1]

class WorkflowTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.career = CareerAgent(str(ROOT/'data'/'jobs.csv'))
        cls.career.jobs_df = cls.career.jobs_df.head(30).copy()
        cls.coordinator = MultiAgentCoordinator(cls.career)
        cls.profile = build_candidate_profile(str(ROOT/'data'/'sample_resume.pdf'))

    def test_rag_modes_and_llm_plan(self):
        self.assertTrue(KnowledgeBase().retrieve('Python developer roadmap testing'))
        jid = self.career.jobs_df.iloc[0]['job_id']
        def fake(prompt):
            if 'Decide whether' in prompt:
                return {'retrieve':True,'query':'Python developer roadmap','reason':'Guide needed'}
            return {'gap_explanation':'The role needs skills that are absent from the extracted resume.',
                    'study_flow':[{'skill':'testing','study_plan':'Learn tests','project':'Test an API',
                                   'duration':'1 week','success_check':'Tests pass',
                                   'knowledge_source':'python_developer.md'}]}
        with patch('utils.multi_agent.completion_json', side_effect=fake) as calls:
            none = self.coordinator.learning.run(self.profile,jid,'none')
            basic = self.coordinator.learning.run(self.profile,jid,'basic')
            agentic = self.coordinator.learning.run(self.profile,jid,'agentic')
        self.assertEqual([len(x['rag']['sources']) for x in (none,basic,agentic)][0],0)
        self.assertTrue(basic['rag']['sources'])
        self.assertTrue(agentic['rag']['retrieval_decision'])
        self.assertEqual([x['learning_plan'][0]['generated_by'] for x in (none,basic,agentic)], ['llm']*3)
        self.assertEqual(calls.call_count,4)

    def test_missing_key_never_silently_templates(self):
        with patch.dict(os.environ, {'GROQ_API_KEY':''}):
            job = self.career.get_job_details(self.career.jobs_df.iloc[0]['job_id'])
            with self.assertRaisesRegex(RuntimeError,'GROQ_API_KEY'):
                self.coordinator.prepare(self.profile,job)

    def test_approval_cannot_be_skipped(self):
        import db
        with tempfile.TemporaryDirectory() as tmp:
            old=db.DB_PATH; db.DB_PATH=str(Path(tmp)/'test.sqlite')
            try:
                db.init_db(); db.save_candidate('c',self.profile)
                db.upsert_application('c','j',tailored_resume='draft')
                for status in ('approved','submitted'):
                    with self.assertRaises(ValueError): db.update_status('c','j',status)
                with self.assertRaises(ValueError): db.transition_application('c','j','apply')
                db.transition_application('c','j','approve')
                self.assertEqual(db.transition_application('c','j','apply')['status'],'submitted')
            finally: db.DB_PATH=old

if __name__=='__main__': unittest.main()
