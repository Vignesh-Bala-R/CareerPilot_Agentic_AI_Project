# CareerPilot multi-agent prototype

Flask application with specialist Profile, Job, Learning, Application and Review agents under a Coordinator. The Learning Agent uses a curated document knowledge base with lexical ranking and source attribution. Retrieval modes: `none`, `basic` (always retrieve), `agentic` (retrieve for skill gaps). The original Groq tool-calling endpoint is also retained.

## Run

Create a Python 3.10+ environment, run `pip install -r requirements.txt`, optionally set `GROQ_API_KEY` and `GROQ_MODEL` in your environment, then run `python app.py`. Visit http://localhost:5000. Without a Groq key, recommendations, document RAG and template application drafts still work; LLM planning and independent draft review are marked unavailable.

The included local job dataset is synthetic and its example.com application URLs are placeholders. Live job APIs require network access. The Apply button records a human action after approval; it does not submit to an external employer site.

## Main flow

`POST /api/upload_resume` (multipart `resume`) returns candidate_id. `GET /api/advise?candidate_id=...&rag_mode=agentic` returns recommendations, top-job analysis and agent trace. `GET /api/job_analysis?candidate_id=...&job_id=...&rag_mode=basic` gives gap, roadmap and cited retrieval. `POST /api/application/prepare`, then `/approve`, then `/apply` require JSON candidate_id and job_id. The generic status endpoint only accepts interview, rejected and withdrawn when the state transition is valid. `/api/profile` restores a profile after a restart.

## Evaluation

Run `python -m unittest discover -s tests -v`. The retrieval modes are executable baselines; quantitative comparison still needs an independently rated profile set and actual measurements. The original report describes a single-agent system and must be revised before presenting this version as the final implementation.

## Limitations

No user accounts or authentication; candidate IDs act as access tokens and this is suitable only for a local academic demo. No real job submission. Resume extraction is rule-based and may miss skills or scanned PDFs. Document retrieval is lexical rather than embedding based. External LLM and live-job behavior needs a configured key/network and should be evaluated separately.
