"""SQLite persistence and enforced application state transitions."""
import os, sqlite3, json
from datetime import datetime, timezone

DB_PATH = os.environ.get('CAREER_DB_PATH', os.path.join(os.path.dirname(__file__), 'career_agent.db'))


def get_conn():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def now(): return datetime.now(timezone.utc).isoformat(timespec='seconds')


def init_db():
    with get_conn() as conn:
        conn.executescript('''
        CREATE TABLE IF NOT EXISTS candidates (
          id TEXT PRIMARY KEY, profile_json TEXT NOT NULL, created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS applications (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          candidate_id TEXT NOT NULL, job_id TEXT NOT NULL,
          status TEXT NOT NULL DEFAULT 'draft', tailored_resume TEXT,
          cover_letter TEXT, application_answers TEXT,
          created_at TEXT NOT NULL, updated_at TEXT NOT NULL,
          UNIQUE(candidate_id, job_id)
        );''')


def save_candidate(candidate_id, profile):
    with get_conn() as conn:
        conn.execute('INSERT OR REPLACE INTO candidates VALUES (?,?,?)',
                     (candidate_id, json.dumps(profile), now()))


def get_candidate(candidate_id):
    if not candidate_id: return None
    with get_conn() as conn:
        row = conn.execute('SELECT profile_json FROM candidates WHERE id=?', (candidate_id,)).fetchone()
    return json.loads(row[0]) if row else None


def get_application(candidate_id, job_id):
    with get_conn() as conn:
        row = conn.execute('SELECT * FROM applications WHERE candidate_id=? AND job_id=?',
                           (candidate_id, job_id)).fetchone()
    return dict(row) if row else None


def list_applications(candidate_id):
    with get_conn() as conn:
        rows = conn.execute('SELECT * FROM applications WHERE candidate_id=? ORDER BY updated_at DESC',
                            (candidate_id,)).fetchall()
    return [dict(row) for row in rows]


def upsert_application(candidate_id, job_id, status='draft', tailored_resume=None,
                       cover_letter=None, application_answers=None):
    if status != 'draft': raise ValueError('Preparation can only create a draft')
    with get_conn() as conn:
        existing = conn.execute('SELECT status FROM applications WHERE candidate_id=? AND job_id=?',
                                (candidate_id, job_id)).fetchone()
        if existing and existing['status'] not in ('draft', 'rejected'):
            raise ValueError('Cannot replace an approved or submitted application')
        conn.execute('''INSERT INTO applications
            (candidate_id,job_id,status,tailored_resume,cover_letter,application_answers,created_at,updated_at)
            VALUES (?,?,?,?,?,?,?,?) ON CONFLICT(candidate_id,job_id) DO UPDATE SET
            status='draft',tailored_resume=excluded.tailored_resume,
            cover_letter=excluded.cover_letter,application_answers=excluded.application_answers,
            updated_at=excluded.updated_at''',
            (candidate_id, job_id, 'draft', tailored_resume, cover_letter,
             application_answers, now(), now()))
    return get_application(candidate_id, job_id)


TRANSITIONS = {
    'draft': {'approve': 'approved', 'reject': 'rejected', 'withdraw': 'withdrawn'},
    'rejected': {'redraft': 'draft', 'withdraw': 'withdrawn'},
    'approved': {'apply': 'submitted', 'withdraw': 'withdrawn'},
    'submitted': {'interview': 'interview', 'reject': 'rejected', 'withdraw': 'withdrawn'},
    'interview': {'reject': 'rejected', 'withdraw': 'withdrawn'},
    'withdrawn': {},
}


def transition_application(candidate_id, job_id, action):
    with get_conn() as conn:
        row = conn.execute('SELECT status FROM applications WHERE candidate_id=? AND job_id=?',
                           (candidate_id, job_id)).fetchone()
        if not row: raise ValueError('Application not prepared')
        new_status = TRANSITIONS.get(row['status'], {}).get(action)
        if not new_status: raise ValueError(f"Cannot {action} from status {row['status']}")
        conn.execute('UPDATE applications SET status=?,updated_at=? WHERE candidate_id=? AND job_id=?',
                     (new_status, now(), candidate_id, job_id))
    return get_application(candidate_id, job_id)


def update_status(candidate_id, job_id, status):
    """Tracking endpoint may update outcomes, never approval or submission."""
    if status not in ('interview', 'rejected', 'withdrawn'):
        raise ValueError('Use the explicit approve/apply actions for those transitions')
    action = {'interview': 'interview', 'rejected': 'reject', 'withdrawn': 'withdraw'}[status]
    return transition_application(candidate_id, job_id, action)
